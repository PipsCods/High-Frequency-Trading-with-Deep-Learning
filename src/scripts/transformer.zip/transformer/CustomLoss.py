import torch
import torch.nn as nn

class CustomLoss(nn.Module):
    def __init__(self, alpha=0.05):
        super().__init__()
        self.alpha = alpha

    def forward(self, output, target):
        mse = ((output - target) ** 2).mean()
        sign_loss = (torch.sign(output) != torch.sign(target)).float().mean()
        return self.alpha * mse + (1 - self.alpha) * sign_loss

